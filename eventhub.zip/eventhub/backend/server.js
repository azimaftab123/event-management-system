const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { readDB, writeDB } = require('./db');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = 'eventhub_super_secret_key_change_me';

app.use(cors());
app.use(bodyParser.json());

// ---- Seed demo user with a real bcrypt hash on first boot ----
function ensureSeed() {
  const db = readDB();
  const demo = db.users.find(u => u.email === 'demo@eventhub.com');
  if (demo && (!demo.password.startsWith('$2a$'))) {
    demo.password = bcrypt.hashSync('demo1234', 10);
    writeDB(db);
  }
}
ensureSeed();

// ---- Auth middleware ----
function authMiddleware(req, res, next) {
  const header = req.headers['authorization'];
  if (!header) return res.status(401).json({ message: 'No token provided' });
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

// ---- AUTH ROUTES ----

app.post('/api/auth/register', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'All fields are required' });
  }
  const db = readDB();
  const exists = db.users.find(u => u.email === email);
  if (exists) return res.status(400).json({ message: 'Email already registered' });

  const hashed = bcrypt.hashSync(password, 10);
  const newUser = { id: 'u' + Date.now(), name, email, password: hashed };
  db.users.push(newUser);
  writeDB(db);

  const token = jwt.sign({ userId: newUser.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: newUser.id, name: newUser.name, email: newUser.email } });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const db = readDB();
  const user = db.users.find(u => u.email === email);
  if (!user) return res.status(400).json({ message: 'Invalid credentials' });

  const valid = bcrypt.compareSync(password, user.password);
  if (!valid) return res.status(400).json({ message: 'Invalid credentials' });

  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

// ---- EVENT ROUTES ----

// Get all events (public — with registration counts)
app.get('/api/events', (req, res) => {
  const db = readDB();
  const eventsWithCounts = db.events.map(ev => ({
    ...ev,
    registeredCount: db.registrations.filter(r => r.eventId === ev.id).length
  }));
  res.json(eventsWithCounts);
});

// Get single event
app.get('/api/events/:id', (req, res) => {
  const db = readDB();
  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ message: 'Event not found' });

  const registeredCount = db.registrations.filter(r => r.eventId === event.id).length;
  res.json({ ...event, registeredCount });
});

// Create event (protected — logged-in users can organize events)
app.post('/api/events', authMiddleware, (req, res) => {
  const { title, description, date, time, location, category, capacity } = req.body;
  if (!title || !date) return res.status(400).json({ message: 'Title and date are required' });

  const db = readDB();
  const newEvent = {
    id: 'e' + Date.now(),
    title,
    description: description || '',
    date,
    time: time || '',
    location: location || 'TBA',
    category: category || 'General',
    capacity: capacity || 100,
    organizerId: req.userId,
    createdAt: new Date().toISOString()
  };
  db.events.push(newEvent);
  writeDB(db);
  res.status(201).json(newEvent);
});

// Update event (only organizer can edit)
app.put('/api/events/:id', authMiddleware, (req, res) => {
  const db = readDB();
  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ message: 'Event not found' });
  if (event.organizerId !== req.userId) return res.status(403).json({ message: 'Not authorized to edit this event' });

  const { title, description, date, time, location, category, capacity } = req.body;
  if (title !== undefined) event.title = title;
  if (description !== undefined) event.description = description;
  if (date !== undefined) event.date = date;
  if (time !== undefined) event.time = time;
  if (location !== undefined) event.location = location;
  if (category !== undefined) event.category = category;
  if (capacity !== undefined) event.capacity = capacity;

  writeDB(db);
  res.json(event);
});

// Delete event (only organizer)
app.delete('/api/events/:id', authMiddleware, (req, res) => {
  const db = readDB();
  const index = db.events.findIndex(e => e.id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Event not found' });
  if (db.events[index].organizerId !== req.userId) return res.status(403).json({ message: 'Not authorized to delete this event' });

  db.events.splice(index, 1);
  db.registrations = db.registrations.filter(r => r.eventId !== req.params.id);
  writeDB(db);
  res.json({ message: 'Event deleted' });
});

// ---- REGISTRATION ROUTES ----

// Register (RSVP) for an event
app.post('/api/events/:id/register', authMiddleware, (req, res) => {
  const db = readDB();
  const event = db.events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ message: 'Event not found' });

  const already = db.registrations.find(r => r.eventId === req.params.id && r.userId === req.userId);
  if (already) return res.status(400).json({ message: 'Already registered for this event' });

  const currentCount = db.registrations.filter(r => r.eventId === req.params.id).length;
  if (currentCount >= event.capacity) return res.status(400).json({ message: 'Event is full' });

  const registration = {
    id: 'r' + Date.now(),
    eventId: req.params.id,
    userId: req.userId,
    registeredAt: new Date().toISOString()
  };
  db.registrations.push(registration);
  writeDB(db);
  res.status(201).json(registration);
});

// Cancel registration
app.delete('/api/events/:id/register', authMiddleware, (req, res) => {
  const db = readDB();
  const index = db.registrations.findIndex(r => r.eventId === req.params.id && r.userId === req.userId);
  if (index === -1) return res.status(404).json({ message: 'Registration not found' });

  db.registrations.splice(index, 1);
  writeDB(db);
  res.json({ message: 'Registration cancelled' });
});

// Get events the logged-in user is registered for
app.get('/api/my-registrations', authMiddleware, (req, res) => {
  const db = readDB();
  const myRegs = db.registrations.filter(r => r.userId === req.userId);
  const myEvents = myRegs.map(r => db.events.find(e => e.id === r.eventId)).filter(Boolean);
  res.json(myEvents);
});

// Get events the logged-in user is organizing
app.get('/api/my-events', authMiddleware, (req, res) => {
  const db = readDB();
  const myEvents = db.events.filter(e => e.organizerId === req.userId);
  res.json(myEvents);
});

app.get('/', (req, res) => {
  res.send('EventHub API is running');
});

app.listen(PORT, () => {
  console.log(`EventHub backend running on http://localhost:${PORT}`);
});
