const API_URL = 'http://localhost:5000/api';

let token = localStorage.getItem('token') || null;
let currentUser = JSON.parse(localStorage.getItem('user') || 'null');

// ---- Elements ----
const authScreen = document.getElementById('authScreen');
const appScreen = document.getElementById('appScreen');
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const loginTab = document.getElementById('loginTab');
const registerTab = document.getElementById('registerTab');
const authError = document.getElementById('authError');
const userNameEl = document.getElementById('userName');
const logoutBtn = document.getElementById('logoutBtn');
const eventForm = document.getElementById('eventForm');

// ---- Tab switching (auth) ----
loginTab.addEventListener('click', () => switchAuthTab('login'));
registerTab.addEventListener('click', () => switchAuthTab('register'));

function switchAuthTab(tab) {
  loginTab.classList.toggle('active', tab === 'login');
  registerTab.classList.toggle('active', tab === 'register');
  loginForm.classList.toggle('hidden', tab !== 'login');
  registerForm.classList.toggle('hidden', tab !== 'register');
}

// ---- Auth: Login ----
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  authError.classList.add('hidden');
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  try {
    const res = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);

    setSession(data.token, data.user);
    showApp();
  } catch (err) {
    showAuthError(err.message);
  }
});

// ---- Auth: Register ----
registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  authError.classList.add('hidden');
  const name = document.getElementById('registerName').value;
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;

  try {
    const res = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message);

    setSession(data.token, data.user);
    showApp();
  } catch (err) {
    showAuthError(err.message);
  }
});

function setSession(tok, user) {
  token = tok;
  currentUser = user;
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(currentUser));
}

function showAuthError(msg) {
  authError.textContent = msg;
  authError.classList.remove('hidden');
}

logoutBtn.addEventListener('click', () => {
  token = null;
  currentUser = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  appScreen.classList.add('hidden');
  authScreen.classList.remove('hidden');
});

function showApp() {
  authScreen.classList.add('hidden');
  appScreen.classList.remove('hidden');
  userNameEl.textContent = currentUser.name;
  loadBrowseView();
}

// ---- Navigation between views ----
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    document.querySelectorAll('.view').forEach(v => v.classList.add('hidden'));
    const view = btn.dataset.view;

    if (view === 'browse') {
      document.getElementById('browseView').classList.remove('hidden');
      loadBrowseView();
    } else if (view === 'myEvents') {
      document.getElementById('myEventsView').classList.remove('hidden');
      loadMyEvents();
    } else if (view === 'myRegistrations') {
      document.getElementById('myRegistrationsView').classList.remove('hidden');
      loadMyRegistrations();
    } else if (view === 'create') {
      document.getElementById('createView').classList.remove('hidden');
    }
  });
});

// ---- Load & render: Browse all events ----
async function loadBrowseView() {
  const res = await fetch(`${API_URL}/events`);
  const events = await res.json();

  const myRegsRes = await fetch(`${API_URL}/my-registrations`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const myRegs = await myRegsRes.json();
  const myRegIds = new Set(myRegs.map(e => e.id));

  const container = document.getElementById('eventList');
  container.innerHTML = '';

  if (events.length === 0) {
    container.innerHTML = '<p style="color:#9a9ab0;">No events yet. Create the first one!</p>';
    return;
  }

  events.forEach(ev => {
    const isRegistered = myRegIds.has(ev.id);
    const full = ev.registeredCount >= ev.capacity;
    const card = document.createElement('div');
    card.className = 'event-card';
    card.innerHTML = `
      <span class="category-badge">${escapeHtml(ev.category)}</span>
      <h3>${escapeHtml(ev.title)}</h3>
      <p class="desc">${escapeHtml(ev.description)}</p>
      <div class="meta">
        <span>📅 ${ev.date} ${ev.time ? 'at ' + ev.time : ''}</span>
        <span>📍 ${escapeHtml(ev.location)}</span>
        <span>${ev.registeredCount}/${ev.capacity} registered</span>
      </div>
      <div class="capacity-bar"><div class="capacity-fill" style="width:${Math.min(100, (ev.registeredCount/ev.capacity)*100)}%"></div></div>
      ${isRegistered ? '<span class="registered-tag">✓ You\'re registered</span>' : ''}
      <div class="event-actions">
        ${isRegistered
          ? `<button class="cancel-btn" data-id="${ev.id}" data-action="cancel">Cancel RSVP</button>`
          : `<button class="register-btn" data-id="${ev.id}" data-action="register" ${full ? 'disabled' : ''}>${full ? 'Full' : 'Register'}</button>`
        }
      </div>
    `;
    container.appendChild(card);
  });

  container.querySelectorAll('[data-action="register"]').forEach(btn => {
    btn.addEventListener('click', () => registerForEvent(btn.dataset.id));
  });
  container.querySelectorAll('[data-action="cancel"]').forEach(btn => {
    btn.addEventListener('click', () => cancelRegistration(btn.dataset.id));
  });
}

async function registerForEvent(eventId) {
  const res = await fetch(`${API_URL}/events/${eventId}/register`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` }
  });
  const data = await res.json();
  if (!res.ok) { alert(data.message); return; }
  loadBrowseView();
}

async function cancelRegistration(eventId) {
  await fetch(`${API_URL}/events/${eventId}/register`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  loadBrowseView();
}

// ---- Load & render: My organized events ----
async function loadMyEvents() {
  const res = await fetch(`${API_URL}/my-events`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const events = await res.json();

  const container = document.getElementById('myEventList');
  container.innerHTML = '';

  if (events.length === 0) {
    container.innerHTML = '<p style="color:#9a9ab0;">You haven\'t created any events yet.</p>';
    return;
  }

  events.forEach(ev => {
    const card = document.createElement('div');
    card.className = 'event-card';
    card.innerHTML = `
      <span class="category-badge">${escapeHtml(ev.category)}</span>
      <h3>${escapeHtml(ev.title)}</h3>
      <p class="desc">${escapeHtml(ev.description)}</p>
      <div class="meta">
        <span>📅 ${ev.date} ${ev.time ? 'at ' + ev.time : ''}</span>
        <span>📍 ${escapeHtml(ev.location)}</span>
      </div>
      <div class="event-actions">
        <button class="delete-btn" data-id="${ev.id}">Delete Event</button>
      </div>
    `;
    container.appendChild(card);
  });

  container.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', () => deleteEvent(btn.dataset.id));
  });
}

async function deleteEvent(eventId) {
  if (!confirm('Delete this event?')) return;
  await fetch(`${API_URL}/events/${eventId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  loadMyEvents();
}

// ---- Load & render: My registrations ----
async function loadMyRegistrations() {
  const res = await fetch(`${API_URL}/my-registrations`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const events = await res.json();

  const container = document.getElementById('myRegList');
  container.innerHTML = '';

  if (events.length === 0) {
    container.innerHTML = '<p style="color:#9a9ab0;">You haven\'t registered for any events yet.</p>';
    return;
  }

  events.forEach(ev => {
    const card = document.createElement('div');
    card.className = 'event-card';
    card.innerHTML = `
      <span class="category-badge">${escapeHtml(ev.category)}</span>
      <h3>${escapeHtml(ev.title)}</h3>
      <div class="meta">
        <span>📅 ${ev.date} ${ev.time ? 'at ' + ev.time : ''}</span>
        <span>📍 ${escapeHtml(ev.location)}</span>
      </div>
      <div class="event-actions">
        <button class="cancel-btn" data-id="${ev.id}">Cancel RSVP</button>
      </div>
    `;
    container.appendChild(card);
  });

  container.querySelectorAll('.cancel-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      await cancelRegistration(btn.dataset.id);
      loadMyRegistrations();
    });
  });
}

// ---- Create event ----
eventForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const title = document.getElementById('eventTitle').value;
  const description = document.getElementById('eventDesc').value;
  const date = document.getElementById('eventDate').value;
  const time = document.getElementById('eventTime').value;
  const location = document.getElementById('eventLocation').value;
  const category = document.getElementById('eventCategory').value;
  const capacity = parseInt(document.getElementById('eventCapacity').value) || 100;

  await fetch(`${API_URL}/events`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify({ title, description, date, time, location, category, capacity })
  });

  eventForm.reset();
  // switch to browse view to show the new event
  document.querySelector('[data-view="browse"]').click();
});

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

// ---- Init ----
if (token && currentUser) {
  showApp();
}
